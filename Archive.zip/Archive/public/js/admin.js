/* 7 KAIH — panel admin */
(function () {
  "use strict";
  var K = window.KAIH, $ = function (s) { return document.querySelector(s); };
  var token = null, config = null;
  try { token = localStorage.getItem("kaih_token"); } catch (e) {}
  var TITLES = {
    dashboard: ["Dashboard Admin", "Selamat datang di panel admin 7 KAIH SMPN 27 SEMARANG"],
    responses: ["Data Kelas", "Pilih kelas, lalu pilih nama siswa"],
    summary: ["Rekap Hasil Kuesioner", "Data diambil dari seluruh responden 7 KAIH"],
    settings: ["Pengaturan", "Informasi sistem"]
  };
  var COLORS = ["#2563eb", "#22a55b", "#f59e0b", "#8b5cf6", "#ef4444", "#06b6d4", "#14b8a6"];

  function api(url, opt) {
    opt = opt || {};
    opt.headers = Object.assign({}, opt.headers, { Authorization: "Bearer " + token });
    return fetch(url, opt).then(function (r) {
      if (r.status === 401) { logout(); throw new Error("Sesi berakhir, silakan login lagi."); }
      return r;
    });
  }
  function logout() {
    try { localStorage.removeItem("kaih_token"); } catch (e) {}
    location.reload();
  }
  function fmt(d) { return d ? new Date(d).toLocaleString("id-ID", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "-"; }

  function statCard(i, ico, tint, val, label, sub) {
    return '<div class="stat" style="--i:' + i + ';--tint:' + tint + '"><div class="ico">' + ico + '</div><div><span>' + label +
      "</span><b>" + val + "</b><small>" + sub + "</small></div></div>";
  }

  function chart(chartEl, labelsEl, items) {
    var max = Math.max.apply(null, items.map(function (x) { return x.v; }).concat([1]));
    chartEl.innerHTML = items.map(function (x, i) {
      return '<div class="bar" title="' + K.esc(x.l) + ": " + x.v + x.suffix + '"><b>' + x.v + x.suffix + '</b><i style="--h:' + Math.round(x.v / max * 100) +
        "%;--c:" + x.c + ";--i:" + i + '"></i></div>';
    }).join("");
    labelsEl.innerHTML = items.map(function (x) { return "<span>" + K.esc(x.l) + "</span>"; }).join("");
  }

  function loadStats() {
    return api("/api/admin/stats").then(function (r) { return r.json(); }).then(function (s) {
      var total = s.total, nClass = Object.keys(s.byClass).length;
      $("#stats").innerHTML =
        statCard(0, "🧑‍🎓", "#e3efff", '<em style="font-style:normal" data-n="' + total + '">0</em>', "Total Responden", "Siswa") +
        statCard(1, "🏫", "#d8f6e4", '<em style="font-style:normal" data-n="' + s.classesWithResponses + '">0</em>', "Kelas Terisi", "dari " + nClass + " kelas") +
        statCard(2, "📝", "#e5e0ff", '<em style="font-style:normal" data-n="' + s.habits.length + '">0</em>', "Kuesioner Aktif", "Kebiasaan") +
        statCard(3, "🕒", "#ffe9cf", '<span style="font-size:14px;color:inherit">' + fmt(s.lastSubmittedAt) + "</span>", "Terakhir Update", "");
      $("#stats").querySelectorAll("[data-n]").forEach(function (e) { K.countUp(e, e.dataset.n, 900); });

      chart($("#classChart"), $("#classLabels"), Object.keys(s.byClass).map(function (c, i) {
        return { l: c, v: s.byClass[c], suffix: "", c: COLORS[i % COLORS.length] };
      }));
      renderSummary(s);
    });
  }

  function renderSummary(s) {
    var hs = s.habitSummary || [];
    var pcts = hs.filter(function (x) { return x.kind === "pct"; });
    var time = function (id) { var x = hs.filter(function (h) { return h.id === id; })[0]; return x && x.value ? x.value : "-"; };
    $("#summaryTop").innerHTML =
      statCard(0, "🧑‍🎓", "#d8f6e4", s.total, "Peserta", "siswa") +
      statCard(1, "☀️", "#fff1cf", time("bangun_pagi"), "Rata-rata Bangun Pagi", "pukul") +
      statCard(2, "🌙", "#e5e0ff", time("tidur_cepat"), "Rata-rata Tidur", "pukul");
    chart($("#habitChart"), $("#habitLabels"), pcts.map(function (x, i) { return { l: x.title, v: x.value, suffix: "%", c: COLORS[i % COLORS.length] }; }));
    $("#summaryCards").innerHTML = hs.map(function (x, i) {
      return '<article class="summary" style="--i:' + i + '"><div>' + K.esc(x.icon) + "</div><h3>" + K.esc(x.title) + "</h3><p>" +
        (x.kind === "time" ? (x.value ? "Rata-rata pukul <b>" + x.value + "</b>" : "Belum ada data") : "<b>" + x.value + "%</b> siswa melakukan kegiatan") + "</p></article>";
    }).join("");
    if (!s.total) { $("#conclusion").innerHTML = "🏆 <div><b>Kesimpulan</b><br>Belum ada responden. Kesimpulan muncul setelah siswa mengisi kuesioner.</div>"; return; }
    var sorted = pcts.slice().sort(function (a, b) { return b.value - a.value; });
    $("#conclusion").innerHTML = "🏆 <div><b>Kesimpulan</b><br>Rata-rata siswa bangun pukul " + time("bangun_pagi") + " dan tidur pukul " + time("tidur_cepat") +
      ". Kegiatan yang paling banyak dilakukan adalah <b>" + K.esc(sorted[0].title) + "</b> (" + sorted[0].value + "%), sedangkan yang perlu ditingkatkan adalah <b>" +
      K.esc(sorted[sorted.length - 1].title) + "</b> (" + sorted[sorted.length - 1].value + "%).</div>";
  }

  var classEl = null, groups = [], curStudent = null, photoUrl = null;
  var GRADES = ["7", "8", "9"];

  function drawClasses() {
    $("#classGrid").innerHTML = GRADES.map(function (g) {
      var list = config.classes.filter(function (c) { return c.charAt(0) === g; });
      return '<div class="panel grade"><h2>Kelas ' + g + '</h2><div class="class-grid">' + list.map(function (c, i) {
        return '<button class="class-btn" style="--i:' + i + '" data-c="' + K.esc(c) + '" type="button">' + K.esc(c) + "</button>";
      }).join("") + "</div></div>";
    }).join("");
  }

  function view(v) {
    ["class", "names", "student"].forEach(function (x) {
      var el = $("#" + (x === "class" ? "classView" : x === "names" ? "nameView" : "studentView"));
      el.classList.toggle("hidden", x !== v);
      if (x === v) { el.style.animation = "none"; void el.offsetWidth; el.style.animation = ""; el.classList.add("page"); }
    });
  }

  function openClass(c) {
    classEl = c;
    api("/api/admin/responses?" + new URLSearchParams({ className: c })).then(function (r) { return r.json(); }).then(function (d) {
      var map = {};
      (Array.isArray(d) ? d : []).forEach(function (r) {
        var key = r.name.trim().toLowerCase() + "|" + r.attendance;
        (map[key] = map[key] || { name: r.name, attendance: r.attendance, subs: [] }).subs.push(r);
      });
      groups = Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return a.name.localeCompare(b.name, "id"); });
      $("#nameTitle").textContent = "Kelas " + c;
      $("#nameSearch").value = "";
      drawNames();
      view("names");
    }).catch(function (e) { K.toast(e.message, "error"); });
  }

  function drawNames() {
    var q = $("#nameSearch").value.trim().toLowerCase();
    var list = groups.map(function (g, i) { return { g: g, i: i }; }).filter(function (x) { return !q || x.g.name.toLowerCase().indexOf(q) >= 0; });
    $("#nameGrid").innerHTML = list.map(function (x, n) {
      return '<button class="name-btn" style="--i:' + n + '" data-g="' + x.i + '" type="button"><span class="av">' + K.esc(x.g.name.charAt(0).toUpperCase()) +
        "</span><span><b>" + K.esc(x.g.name) + "</b><small>Absen " + x.g.attendance + "</small></span></button>";
    }).join("") || '<p class="muted">' + (groups.length ? "Nama tidak ditemukan." : "Belum ada siswa yang mengisi di kelas ini.") + "</p>";
  }

  function ansText(v) { return v ? String(v).split("; ").join(", ") : "-"; }
  function fmtDay(iso) {
    return /^\d{4}-\d{2}-\d{2}$/.test(iso || "") ? new Date(iso + "T00:00:00Z").toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }) : "";
  }

  function openStudent(g) {
    curStudent = g;
    $("#studentTitle").textContent = g.name + " · Kelas " + classEl + " · Absen " + g.attendance;
    $("#submissions").innerHTML = g.subs.map(function (r, si) {
      var day = fmtDay(r.answers.tanggal) || fmtLong(r.submittedAt);
      return '<div class="panel sub" style="--i:' + si + '"><div class="sub-head"><span>📅 Tanggal pelaksanaan: <b>' + K.esc(day) + "</b><br><small class=\"muted\">Dikirim " + fmtLong(r.submittedAt) + "</small></span>" +
        (r.hasPhoto ? '<span class="pill">📷 ada foto</span>' : "") + "</div>" +
        config.fields.filter(function (f) { return f.id !== "tanggal"; }).map(function (f) {
          return '<div class="ans-row"><button class="text-btn" data-s="' + si + '" data-h="' + K.esc(f.id) + '" type="button">Lihat</button><em>' + K.esc(f.icon) +
            "</em><div><b>" + K.esc(f.title) + "</b><small>" + K.esc(ansText(r.answers[f.id])) + "</small></div></div>";
        }).join("") + "</div>";
    }).join("");
    view("student");
  }

  function fmtLong(d) {
    return new Date(d).toLocaleString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });
  }

  function openDetail(r, f) {
    $("#modalTitle").textContent = f.title;
    var ans = r.answers[f.id] ? String(r.answers[f.id]).split("; ").map(function (x) { return K.esc(x); }).join("<br>") : "-";
    $("#modalBody").innerHTML =
      '<div class="info-grid"><div><span>Nama</span><b>' + K.esc(r.name) + "</b></div><div><span>Kelas / Absen</span><b>" + K.esc(r.className) + " / " + r.attendance +
      "</b></div><div><span>Tanggal Pelaksanaan</span><b>" + K.esc(fmtDay(r.answers.tanggal) || "-") + "</b></div><div><span>Waktu Kirim</span><b>" + fmtLong(r.submittedAt) +
      '</b></div></div><div class="ans"><em>' + K.esc(f.icon) + "</em><div><small>Jawaban</small><b>" + ans + "</b></div></div>" +
      '<h3 class="modal-sub">📷 Dokumentasi</h3><div id="photoBox" class="photo-box muted">' + (r.hasPhoto ? "Memuat foto..." : "Tidak ada foto dokumentasi.") + "</div>";
    $("#modal").classList.remove("hidden");
    if (!r.hasPhoto) return;
    api("/api/admin/photo/" + encodeURIComponent(r.id)).then(function (res) {
      if (!res.ok) throw new Error("Foto tidak ditemukan.");
      return res.blob();
    }).then(function (b) {
      var box = $("#photoBox");
      if (!box || $("#modal").classList.contains("hidden")) return;
      photoUrl = URL.createObjectURL(b);
      box.innerHTML = '<img src="' + photoUrl + '" alt="Foto dokumentasi">';
    }).catch(function (e) { var box = $("#photoBox"); if (box) box.textContent = e.message; });
  }
  function closeDetail() {
    $("#modal").classList.add("hidden");
    if (photoUrl) { URL.revokeObjectURL(photoUrl); photoUrl = null; }
  }

  function download(url, name) {
    api(url).then(function (r) { if (!r.ok) throw new Error("Gagal mengunduh."); return r.blob(); }).then(function (b) {
      var a = document.createElement("a");
      a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    }).catch(function (e) { K.toast(e.message, "error"); });
  }

  function openPage(p) {
    document.querySelectorAll(".page").forEach(function (x) { x.classList.add("hidden"); });
    $("#" + p).classList.remove("hidden");
    document.querySelectorAll(".side[data-page]").forEach(function (x) { x.classList.toggle("active", x.dataset.page === p); });
    $("#pageTitle").textContent = TITLES[p][0]; $("#pageSub").textContent = TITLES[p][1];
    if (p === "dashboard" || p === "summary") loadStats().catch(function (e) { K.toast(e.message, "error"); });
    if (p === "responses") view("class");
  }

  function boot() {
    if (!token) return;
    fetch("/api/config").then(function (r) { return r.json(); }).then(function (c) {
      config = c;
      drawClasses();
      return api("/api/admin/stats");
    }).then(function (r) {
      if (!r.ok) throw new Error("x");
      $("#login").classList.add("hidden"); $("#app").classList.remove("hidden");
      return loadStats();
    }).catch(function () { /* token tidak valid: tetap di halaman login */ });
  }

  $("#loginBtn").addEventListener("click", function () {
    var btn = $("#loginBtn");
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Masuk...';
    fetch("/api/admin/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: $("#user").value, password: $("#pass").value })
    }).then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); }).then(function (res) {
      if (!res.ok) throw new Error(res.d.error || "Login gagal.");
      token = res.d.token;
      try { localStorage.setItem("kaih_token", token); } catch (e) {}
      K.toast("Login berhasil. Selamat datang!", "ok");
      boot();
    }).catch(function (e) { K.toast(e.message || "Gagal terhubung ke server.", "error"); })
      .then(function () { btn.disabled = false; btn.textContent = "Login →"; });
  });
  $("#pass").addEventListener("keydown", function (e) { if (e.key === "Enter") $("#loginBtn").click(); });
  $("#user").addEventListener("keydown", function (e) { if (e.key === "Enter") $("#pass").focus(); });
  $("#logout").addEventListener("click", logout);
  document.querySelectorAll(".side[data-page]").forEach(function (b) { b.addEventListener("click", function () { openPage(b.dataset.page); }); });
  $("#export").addEventListener("click", function () { download("/api/admin/export", "7-kaih-data.csv"); });
  $("#backup").addEventListener("click", function () { download("/api/admin/backup", "7-kaih.sqlite"); });
  $("#classGrid").addEventListener("click", function (e) { var b = e.target.closest("[data-c]"); if (b) openClass(b.dataset.c); });
  $("#nameGrid").addEventListener("click", function (e) { var b = e.target.closest("[data-g]"); if (b) openStudent(groups[Number(b.dataset.g)]); });
  $("#nameSearch").addEventListener("input", drawNames);
  $("#responses").addEventListener("click", function (e) { var b = e.target.closest("[data-go]"); if (b) view(b.dataset.go); });
  $("#submissions").addEventListener("click", function (e) {
    var b = e.target.closest("[data-h]");
    if (!b || !curStudent) return;
    var f = config.fields.filter(function (x) { return x.id === b.dataset.h; })[0];
    if (f) openDetail(curStudent.subs[Number(b.dataset.s)], f);
  });
  $("#closeModal").addEventListener("click", closeDetail);
  $("#modal").addEventListener("click", function (e) { if (e.target.id === "modal") closeDetail(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeDetail(); });
  boot();
})();

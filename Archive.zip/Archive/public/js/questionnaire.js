/* 7 KAIH — kuesioner per bagian (disamakan dengan Google Form) */
(function () {
  "use strict";
  var K = window.KAIH, $ = function (s) { return document.querySelector(s); };
  var cfg = null, step = 0, answers = {}, sending = false, photoData = null;

  function total() { return cfg.sections.length + 1; } // + langkah foto

  function todayISO() {
    var d = new Date(), p = function (n) { return String(n).padStart(2, "0"); };
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
  }

  function setStep(n) {
    document.querySelectorAll(".step").forEach(function (el) {
      var s = Number(el.dataset.s);
      el.classList.toggle("active", s === n);
      el.classList.toggle("done", s < n);
      if (s < n) el.querySelector("i").textContent = "✓";
    });
    $("#stepFill").style.width = ((n - 1) / 2) * 100 + "%";
  }

  function show(id) {
    ["identity", "questions", "done"].forEach(function (x) { $("#" + x).classList.toggle("hidden", x !== id); });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function swapIn(card, dir) {
    card.classList.remove("swap"); void card.offsetWidth;
    card.dataset.dir = dir || 1; card.classList.add("swap");
  }

  function progress() {
    var pct = Math.round(step / total() * 100);
    $("#progressFill").style.width = pct + "%";
    $("#qPct").textContent = pct + "%";
  }

  function fieldsOf(sec) { return cfg.fields.filter(function (f) { return f.section === sec.id; }); }

  function fieldHtml(f) {
    var v = answers[f.id], body = "";
    if (f.type === "checkbox") {
      var sel = Array.isArray(v) ? v : [];
      body = '<div class="options">' + f.options.map(function (o, i) {
        return '<label class="option chk" style="--i:' + i + '"><input type="checkbox" name="' + f.id + '" value="' + K.esc(o) + '"' +
          (sel.indexOf(o) >= 0 ? " checked" : "") + "><span>" + K.esc(o) + "</span></label>";
      }).join("") + "</div>";
    } else if (f.type === "date") {
      body = '<input type="date" name="' + f.id + '" max="' + todayISO() + '" value="' + K.esc(v || "") + '">';
    } else if (f.type === "time") {
      body = '<input type="time" name="' + f.id + '" value="' + K.esc((v || "").replace(".", ":")) + '">';
    } else {
      body = '<input type="text" name="' + f.id + '" maxlength="' + (f.max || 300) + '" placeholder="Jawaban Anda' +
        (f.required ? " (isi - jika tidak ada)" : "") + '" value="' + K.esc(v || "") + '">';
    }
    return '<div class="field" data-f="' + f.id + '"><div class="f-title">' + K.esc(f.title) + (f.required ? ' <b class="req">*</b>' : "") + "</div>" +
      (f.hint ? '<div class="f-hint">' + K.esc(f.hint) + "</div>" : "") + body + "</div>";
  }

  function photoCard() {
    return '<div class="q-title"><div class="q-ico">📷</div><div><h3>Dokumentasi <b class="req">*</b></h3><p>Dokumentasi (bisa di kolase &amp; file diberi nama lengkap + kelas). ' +
      "Upload 1 file gambar, maksimal 1 MB (otomatis dikecilkan).</p></div></div>" +
      (photoData
        ? '<div class="photo-preview"><img src="' + photoData + '" alt="Pratinjau dokumentasi"><button type="button" class="btn secondary" data-rm="1">🗑 Hapus / Ganti Foto</button></div>'
        : '<label class="drop" id="drop"><input type="file" id="photoInput" accept="image/*"><span class="drop-ico">🖼️</span><b>Ketuk untuk memilih foto</b><small>JPG, PNG, atau WEBP</small></label>');
  }

  function dataSize(url) { return Math.floor((url.length - url.indexOf(",") - 1) * 3 / 4); }

  function compress(file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//.test(file.type)) return reject(new Error("File harus berupa gambar."));
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        var tries = [[1280, 0.8], [1280, 0.65], [1024, 0.65], [1024, 0.5], [800, 0.5], [640, 0.45]], out = null;
        for (var i = 0; i < tries.length; i++) {
          var sc = Math.min(1, tries[i][0] / Math.max(img.width, img.height));
          var cv = document.createElement("canvas");
          cv.width = Math.max(1, Math.round(img.width * sc)); cv.height = Math.max(1, Math.round(img.height * sc));
          var ctx = cv.getContext("2d");
          ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cv.width, cv.height);
          ctx.drawImage(img, 0, 0, cv.width, cv.height);
          out = cv.toDataURL("image/jpeg", tries[i][1]);
          if (dataSize(out) <= 1000000) return resolve(out);
        }
        reject(new Error("Foto terlalu besar, coba foto lain."));
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("Foto tidak bisa dibaca. Coba foto lain.")); };
      img.src = url;
    });
  }

  function render(dir) {
    var card = $("#qCard"), next = $("#next");
    if (step === cfg.sections.length) {
      card.innerHTML = photoCard();
      $("#qCount").textContent = "Bagian " + total() + " dari " + total() + " · Dokumentasi";
      next.textContent = "Kirim Jawaban ✓";
    } else {
      var s = cfg.sections[step];
      card.innerHTML = '<div class="q-title"><div class="q-ico">' + K.esc(s.icon) + "</div><div><h3>" + K.esc(s.title) + "</h3><p>" + K.esc(s.intro || "") + "</p></div></div>" +
        fieldsOf(s).map(fieldHtml).join("");
      $("#qCount").textContent = "Bagian " + (step + 1) + " dari " + total() + " · " + s.title;
      next.textContent = "Selanjutnya →";
    }
    next.disabled = false;
    swapIn(card, dir);
    progress();
  }

  // ambil nilai input pada bagian yang sedang tampil
  function collect() {
    if (step >= cfg.sections.length) return;
    fieldsOf(cfg.sections[step]).forEach(function (f) {
      var els = document.querySelectorAll('#qCard [name="' + f.id + '"]');
      if (f.type === "checkbox") {
        answers[f.id] = Array.prototype.filter.call(els, function (e) { return e.checked; }).map(function (e) { return e.value; });
      } else if (els[0]) {
        answers[f.id] = els[0].value.trim();
      }
    });
  }

  function validate() {
    document.querySelectorAll("#qCard .field.bad").forEach(function (e) { e.classList.remove("bad"); });
    var first = null;
    fieldsOf(cfg.sections[step]).forEach(function (f) {
      var v = answers[f.id], bad = false;
      if (f.required) bad = f.type === "checkbox" ? !(v && v.length) : !v;
      if (!bad && f.type === "date" && v && v > todayISO()) bad = true;
      if (bad) {
        var el = document.querySelector('#qCard [data-f="' + f.id + '"]');
        if (el) { el.classList.add("bad"); first = first || el; }
      }
    });
    if (first) first.scrollIntoView({ behavior: "smooth", block: "center" });
    return !first;
  }

  function flash(el) {
    el.classList.add("err");
    setTimeout(function () { el.classList.remove("err"); }, 600);
  }

  function start() {
    var n = $("#name"), c = $("#className"), a = $("#attendance");
    var bad = false;
    if (!n.value.trim()) { flash(n); bad = true; }
    if (!c.value) { flash(c); bad = true; }
    var num = Number(a.value);
    if (!a.value || !Number.isInteger(num) || num < 1 || num > 60) { flash(a); bad = true; }
    if (bad) return K.toast("Lengkapi nama, kelas, dan nomor absen (1–60).", "error");
    if (!cfg) return K.toast("Data belum termuat, coba muat ulang halaman.", "error");
    step = 0; setStep(2); show("questions"); render(1);
  }

  function submit() {
    if (sending) return;
    sending = true;
    var btn = $("#next");
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Mengirim...';
    fetch("/api/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: $("#name").value.trim(),
        className: $("#className").value,
        attendance: $("#attendance").value,
        answers: answers,
        photo: photoData
      })
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) { return { ok: r.ok, d: d }; });
    }).then(function (res) {
      if (!res.ok) throw new Error(res.d.error || "Gagal menyimpan.");
      setStep(3); show("done"); K.confetti($("#done"), 40);
      document.querySelectorAll(".step")[2].querySelector("i").textContent = "✓";
    }).catch(function (e) {
      K.toast(e.message || "Gagal terhubung ke server.", "error");
      btn.disabled = false; btn.textContent = "Kirim Jawaban ✓";
    }).then(function () { sending = false; });
  }

  $("#start").addEventListener("click", start);
  $("#attendance").addEventListener("keydown", function (e) { if (e.key === "Enter") start(); });

  $("#qCard").addEventListener("change", function (e) {
    if (e.target.id !== "photoInput") return;
    var f = e.target.files && e.target.files[0];
    if (!f) return;
    compress(f).then(function (d) {
      photoData = d; $("#qCard").innerHTML = photoCard(); swapIn($("#qCard"), 1);
    }).catch(function (err) { K.toast(err.message, "error"); e.target.value = ""; });
  });

  $("#qCard").addEventListener("click", function (e) {
    if (e.target.closest("[data-rm]")) { photoData = null; $("#qCard").innerHTML = photoCard(); swapIn($("#qCard"), -1); }
  });

  $("#next").addEventListener("click", function () {
    if (step < cfg.sections.length) {
      collect();
      if (!validate()) return K.toast("Masih ada isian wajib yang kosong.", "error");
      step++; render(1);
    } else {
      if (!photoData) { var d = $("#drop"); if (d) flash(d); return K.toast("Dokumentasi wajib diunggah.", "error"); }
      submit();
    }
  });

  $("#back").addEventListener("click", function () {
    collect();
    if (step > 0) { step--; render(-1); } else { setStep(1); show("identity"); }
  });

  fetch("/api/config").then(function (r) { return r.json(); }).then(function (c) {
    cfg = c;
    var s = $("#className");
    c.classes.forEach(function (x) { var o = document.createElement("option"); o.value = x; o.textContent = x; s.appendChild(o); });
  }).catch(function () { K.toast("Gagal memuat data dari server.", "error"); });
})();

/* 7 KAIH — kuesioner satu pertanyaan per layar */
(function () {
  "use strict";
  var K = window.KAIH, $ = function (s) { return document.querySelector(s); };
  var OPTS = [
    ["Selalu", "Selalu (setiap hari)"],
    ["Sering", "Sering (4–5 kali seminggu)"],
    ["Kadang-kadang", "Kadang-kadang (2–3 kali seminggu)"],
    ["Jarang", "Jarang (1 kali seminggu)"],
    ["Tidak Pernah", "Tidak Pernah"]
  ];
  var cfg = null, idx = 0, answers = {}, sending = false, photoData = null;

  function setStep(n) {
    document.querySelectorAll(".step").forEach(function (el) {
      var s = Number(el.dataset.s);
      el.classList.toggle("active", s === n);
      el.classList.toggle("done", s < n);
      if (s < n) el.querySelector("i").textContent = "✓";
    });
    $("#stepFill").style.width = ((n - 1) / 2) * 100 + "%";
  }

  function show(id) {
    ["identity", "questions", "done"].forEach(function (x) { $("#" + x).classList.toggle("hidden", x !== id); });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function progress() {
    var done = Object.keys(answers).length, pct = Math.round(done / cfg.habits.length * 100);
    $("#progressFill").style.width = pct + "%";
    $("#qPct").textContent = pct + "%";
  }

  function swapIn(card, dir) {
    card.classList.remove("swap"); void card.offsetWidth;
    card.dataset.dir = dir || 1; card.classList.add("swap");
  }

  function photoCard() {
    return '<div class="q-title"><div class="q-ico">📷</div><div><h3>Foto Bukti Kegiatan</h3><p>Kirim 1 foto bukti kegiatanmu (misalnya salat atau ibadah, olahraga, dll). ' +
      'Punya lebih dari satu foto? Gabungkan dulu menjadi satu kolase. Langkah ini opsional.</p></div></div>' +
      (photoData
        ? '<div class="photo-preview"><img src="' + photoData + '" alt="Pratinjau foto bukti"><button type="button" class="btn secondary" data-rm="1">🗑 Hapus / Ganti Foto</button></div>'
        : '<label class="drop"><input type="file" id="photoInput" accept="image/*"><span class="drop-ico">🖼️</span><b>Ketuk untuk memilih foto</b><small>JPG, PNG, atau WEBP · otomatis dikecilkan</small></label>');
  }

  function renderPhoto(dir) {
    $("#qCard").innerHTML = photoCard();
    swapIn($("#qCard"), dir);
    $("#qCount").textContent = "Langkah terakhir: Foto Bukti";
    var next = $("#next");
    next.disabled = false;
    next.textContent = "Kirim Jawaban ✓";
    progress();
  }

  function compress(file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//.test(file.type)) return reject(new Error("File harus berupa gambar."));
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        var max = 1280, sc = Math.min(1, max / Math.max(img.width, img.height));
        var cv = document.createElement("canvas");
        cv.width = Math.max(1, Math.round(img.width * sc)); cv.height = Math.max(1, Math.round(img.height * sc));
        var ctx = cv.getContext("2d");
        ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cv.width, cv.height);
        ctx.drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url);
        resolve(cv.toDataURL("image/jpeg", 0.8));
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("Foto tidak bisa dibaca. Coba foto lain.")); };
      img.src = url;
    });
  }

  function render(dir) {
    if (idx === cfg.habits.length) return renderPhoto(dir);
    var h = cfg.habits[idx], last = false;
    var card = $("#qCard");
    card.innerHTML =
      '<div class="q-title"><div class="q-ico">' + K.esc(h.icon) + "</div><div><h3>" + (idx + 1) + ". " + K.esc(h.title) +
      "</h3><p>" + K.esc(h.question) + '</p></div></div><div class="options">' +
      OPTS.map(function (o, i) {
        return '<label class="option" style="--i:' + i + '"><input type="radio" name="opt" value="' + o[0] + '"' +
          (answers[h.id] === o[0] ? " checked" : "") + "><span>" + o[1] + "</span></label>";
      }).join("") + "</div>";
    swapIn(card, dir);
    $("#qCount").textContent = "Pertanyaan " + (idx + 1) + " dari " + cfg.habits.length;
    $("#back").disabled = false;
    var next = $("#next");
    next.disabled = !answers[h.id];
    next.textContent = "Selanjutnya →";
    progress();
  }

  function flash(el) {
    el.classList.add("err");
    setTimeout(function () { el.classList.remove("err"); }, 600);
  }

  function start() {
    var n = $("#name"), c = $("#className"), a = $("#attendance");
    var bad = false;
    if (!n.value.trim()) { flash(n); bad = true; }
    if (!c.value) { flash(c); bad = true; }
    var num = Number(a.value);
    if (!a.value || !Number.isInteger(num) || num < 1 || num > 60) { flash(a); bad = true; }
    if (bad) return K.toast("Lengkapi nama, kelas, dan nomor absen (1–60).", "error");
    if (!cfg) return K.toast("Data belum termuat, coba muat ulang halaman.", "error");
    idx = 0; setStep(2); show("questions"); render(1);
  }

  function submit() {
    if (sending) return;
    sending = true;
    var btn = $("#next");
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Mengirim...';
    fetch("/api/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: $("#name").value.trim(),
        className: $("#className").value,
        attendance: $("#attendance").value,
        answers: answers,
        photo: photoData
      })
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) { return { ok: r.ok, d: d }; });
    }).then(function (res) {
      if (!res.ok) throw new Error(res.d.error || "Gagal menyimpan.");
      setStep(3); show("done"); K.confetti($("#done"), 40);
      document.querySelectorAll(".step")[2].querySelector("i").textContent = "✓";
    }).catch(function (e) {
      K.toast(e.message || "Gagal terhubung ke server.", "error");
      btn.disabled = false; btn.textContent = "Kirim Jawaban ✓";
    }).then(function () { sending = false; });
  }

  $("#start").addEventListener("click", start);
  $("#attendance").addEventListener("keydown", function (e) { if (e.key === "Enter") start(); });

  $("#qCard").addEventListener("change", function (e) {
    if (e.target.id === "photoInput") {
      var f = e.target.files && e.target.files[0];
      if (!f) return;
      compress(f).then(function (d) {
        photoData = d; $("#qCard").innerHTML = photoCard(); swapIn($("#qCard"), 1);
      }).catch(function (err) { K.toast(err.message, "error"); e.target.value = ""; });
      return;
    }
    if (e.target.name !== "opt") return;
    answers[cfg.habits[idx].id] = e.target.value;
    $("#next").disabled = false;
    progress();
  });

  $("#qCard").addEventListener("click", function (e) {
    if (e.target.closest("[data-rm]")) { photoData = null; $("#qCard").innerHTML = photoCard(); swapIn($("#qCard"), -1); }
  });

  $("#next").addEventListener("click", function () {
    if (idx < cfg.habits.length) {
      if (!answers[cfg.habits[idx].id]) return;
      idx++; render(1);
    } else submit();
  });

  $("#back").addEventListener("click", function () {
    if (idx > 0) { idx--; render(-1); } else { setStep(1); show("identity"); }
  });

  fetch("/api/config").then(function (r) { return r.json(); }).then(function (c) {
    cfg = c;
    var s = $("#className");
    c.classes.forEach(function (x) { var o = document.createElement("option"); o.value = x; o.textContent = x; s.appendChild(o); });
  }).catch(function () { K.toast("Gagal memuat data dari server.", "error"); });
})();

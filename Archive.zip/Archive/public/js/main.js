/* 7 KAIH — helper bersama + animasi (dipakai semua halaman) */
(function () {
  "use strict";
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (m) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[m];
    });
  }

  function toast(msg, type) {
    var old = document.querySelector(".toast");
    if (old) old.remove();
    var t = document.createElement("div");
    t.className = "toast " + (type || "");
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function () { t.style.transition = "opacity .3s"; t.style.opacity = "0"; }, 2800);
    setTimeout(function () { t.remove(); }, 3200);
  }

  function countUp(el, to, ms) {
    to = Number(to) || 0;
    if (reduce || to === 0) { el.textContent = to; return; }
    var start = performance.now();
    ms = ms || 1000;
    (function tick(now) {
      var p = Math.min(1, (now - start) / ms);
      el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(tick);
    })(start);
  }

  function confetti(host, n) {
    if (reduce) return;
    var colors = ["#2563eb", "#22a55b", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];
    for (var i = 0; i < (n || 36); i++) {
      var c = document.createElement("i");
      c.className = "confetti";
      c.style.background = colors[i % colors.length];
      c.style.setProperty("--x", (Math.random() * 440 - 220) + "px");
      c.style.setProperty("--y", (Math.random() * 300 - 40) + "px");
      c.style.setProperty("--r", (Math.random() * 720 - 360) + "deg");
      c.style.animationDelay = Math.random() * 0.3 + "s";
      host.appendChild(c);
      setTimeout(function (el) { el.remove(); }.bind(null, c), 2200);
    }
  }

  var io = null;
  function reveal(root) {
    var list = (root || document).querySelectorAll("[data-reveal]:not(.in)");
    if (!("IntersectionObserver" in window)) { list.forEach(function (e) { e.classList.add("in"); }); return; }
    io = io || new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    list.forEach(function (e, i) {
      if (!e.style.getPropertyValue("--d")) e.style.setProperty("--d", (i % 8) * 0.07 + "s");
      io.observe(e);
    });
  }

  function tilt(root) {
    if (reduce) return;
    (root || document).querySelectorAll("[data-tilt]").forEach(function (el) {
      if (el._tilt) return;
      el._tilt = true;
      el.addEventListener("pointermove", function (e) {
        var r = el.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        el.style.transform = "perspective(700px) rotateY(" + x * 14 + "deg) rotateX(" + -y * 14 + "deg) translateY(-6px)";
      });
      el.addEventListener("pointerleave", function () { el.style.transform = ""; });
    });
  }

  // ripple pada tombol
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest(".btn");
    if (!b || reduce) return;
    var r = b.getBoundingClientRect(), s = document.createElement("span");
    s.className = "rip";
    s.style.left = e.clientX - r.left + "px";
    s.style.top = e.clientY - r.top + "px";
    b.appendChild(s);
    setTimeout(function () { s.remove(); }, 650);
  });

  window.KAIH = { esc: esc, toast: toast, countUp: countUp, confetti: confetti, reveal: reveal, tilt: tilt, reduce: reduce };

  function init() {
    document.body.classList.add("loaded");
    reveal();
    var bar = document.querySelector(".topbar");
    if (bar) window.addEventListener("scroll", function () { bar.classList.toggle("scrolled", window.scrollY > 8); }, { passive: true });

    // parallax ringan di hero
    var art = document.querySelector(".hero-art");
    if (art && !reduce) {
      art.addEventListener("pointermove", function (e) {
        var r = art.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        art.querySelectorAll(".chip").forEach(function (c, i) {
          var k = (i + 1) * 8;
          c.style.translate = x * k + "px " + y * k + "px";
        });
        var sc = art.querySelector(".student-card");
        if (sc) sc.style.rotate = x * 6 + "deg";
      });
    }

    // halaman beranda: render 7 kebiasaan
    var grid = document.getElementById("habitGrid");
    if (grid) {
      var fallback = [
        { title: "Bangun Pagi", icon: "☀️" }, { title: "Beribadah", icon: "🙏" }, { title: "Berolahraga", icon: "🏃" },
        { title: "Makan Sehat", icon: "🍎" }, { title: "Gemar Belajar", icon: "📚" }, { title: "Bermasyarakat", icon: "👥" },
        { title: "Tidur Cepat", icon: "🌙" }
      ];
      var draw = function (habits) {
        grid.innerHTML = habits.map(function (h, i) {
          return '<article class="habit" data-reveal data-tilt><div class="habit-icon">' + esc(h.icon) + "</div><span>" + (i + 1) + "</span><h3>" + esc(h.title) + "</h3></article>";
        }).join("");
        reveal(grid); tilt(grid);
      };
      fetch("/api/config").then(function (r) { return r.json(); })
        .then(function (c) { draw(c.habits || fallback); })
        .catch(function () { draw(fallback); });
    }

    // menu aktif sesuai bagian yang terlihat
    var links = document.querySelectorAll('.topbar nav a[href^="#"]');
    if (links.length && "IntersectionObserver" in window) {
      var so = new IntersectionObserver(function (es) {
        es.forEach(function (en) {
          if (en.isIntersecting) links.forEach(function (a) { a.classList.toggle("active", a.getAttribute("href") === "#" + en.target.id); });
        });
      }, { threshold: 0.4 });
      links.forEach(function (a) { var t = document.querySelector(a.getAttribute("href")); if (t) so.observe(t); });
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

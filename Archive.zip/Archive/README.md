# 7 KAIH SMPN 27 SEMARANG

## Versi dengan database SQLite

ZIP ini sudah menyertakan **database SQLite asli**:
`data/7-kaih.sqlite`

Database otomatis dipakai oleh `index.js` untuk menyimpan:
- nama siswa
- kelas
- nomor absen
- waktu pengisian
- seluruh jawaban 7 kebiasaan

### Menjalankan di VPS

Gunakan Node.js 18+ (disarankan Node.js 20 atau 22).

```bash
cd 7-kaih-smpn27
npm install
cp .env.example .env
```

Edit `.env`:
```env
PORT=3000
ADMIN_USER=admin
ADMIN_PASSWORD=ganti-password-kuat
SESSION_SECRET=ganti-dengan-random-string-panjang
```

Jalankan:
```bash
npm start
```

Buka:
- `http://IP-VPS:3000`
- Admin: `http://IP-VPS:3000/admin.html`

Default jika `.env` belum diubah:
- Username: `admin`
- Password: `admin123`

**Wajib ganti password sebelum website dibuka ke publik.**

### Database

File:
`data/7-kaih.sqlite`

Untuk backup database, admin API juga menyediakan endpoint internal `/api/admin/backup` setelah login.

### Isi ZIP
- `index.js` — server Express + SQLite
- `package.json` — dependency
- `.env.example`
- `data/7-kaih.sqlite` — DATABASE ASLI
- `public/index.html`
- `public/questionnaire.html`
- `public/admin.html`
- `public/style.css` — tema + semua animasi
- `public/js/main.js` — animasi bersama (reveal, tilt, ripple, confetti, toast)
- `public/js/questionnaire.js` — kuesioner satu pertanyaan per layar
- `public/js/admin.js` — panel admin (dashboard, tabel, rekap, modal)
- `public/assets/smpn27-logo.png` — logo SMPN 27
- `public/assets/design-preview.png` — preview desain UI
- `README.md`

Daftar kelas sementara: 7A–7I, 8A–8I, 9A–9I.


### Catatan update
- `.env` kini otomatis dibaca oleh `index.js`.
- Endpoint `/api/admin/stats` menambah `lastSubmittedAt`.
- Animasi otomatis nonaktif bagi pengguna dengan pengaturan *reduce motion*.

// Muat file .env (tanpa dependency tambahan)
try {
  require("fs").readFileSync(require("path").join(__dirname, ".env"), "utf8").split(/\r?\n/).forEach((line) => {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith("#") && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  });
} catch {}

const express = require("express");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 3000);
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const fs = require("fs");
const { run, all, get, ready, DB_FILE, DATA_DIR, driver } = require("./db");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// Secret sesi: dari env, atau dibuat otomatis & disimpan agar login tidak hilang saat restart
function loadSecret() {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET !== "ganti-session-secret") return process.env.SESSION_SECRET;
  const f = path.join(DATA_DIR, ".session-secret");
  try { return fs.readFileSync(f, "utf8").trim(); } catch {}
  const v = crypto.randomBytes(32).toString("hex");
  try { fs.writeFileSync(f, v, { mode: 0o600 }); } catch {}
  return v;
}
const SESSION_SECRET = loadSecret();
if (["admin123", "ganti-password-ini"].includes(ADMIN_PASSWORD)) {
  console.warn("[PERINGATAN] ADMIN_PASSWORD masih default. Ganti lewat Startup/Variables panel atau file .env!");
}
app.set("trust proxy", true); // di belakang Nginx/Cloudflare/domain sendiri
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "same-origin");
  next();
});

app.use(express.json({ limit: "3mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const classes = [];
for (const grade of [7, 8, 9]) {
  for (const letter of "ABCDEFGH") classes.push(`${grade}${letter}`);
}

const habits = [
  { id: "bangun_pagi", title: "Bangun Pagi", icon: "☀️", question: "Pukul berapa kamu bangun pagi?" },
  { id: "beribadah", title: "Beribadah", icon: "🙏", question: "Ibadah apa saja yang kamu laksanakan sesuai agamamu?" },
  { id: "berolahraga", title: "Berolahraga", icon: "🏃", question: "Olahraga apa yang kamu lakukan?" },
  { id: "makan_sehat", title: "Makan Sehat", icon: "🍎", question: "Makanan sehat bergizi apa yang kamu makan?" },
  { id: "gemar_belajar", title: "Gemar Belajar", icon: "📚", question: "Apa yang kamu pelajari atau baca?" },
  { id: "bermasyarakat", title: "Bermasyarakat", icon: "👥", question: "Kegiatan bermasyarakat apa yang kamu lakukan?" },
  { id: "tidur_cepat", title: "Tidur Cepat", icon: "🌙", question: "Pukul berapa kamu tidur?" }
];

// ===== Isi formulir (disamakan dengan Google Form) =====
// Ubah teks pertanyaan / pilihan cukup di bagian ini.
const NOTE = "(Isilah dengan tanda (-) jika tidak sesuai dengan agama yang diyakini)";
const ISLAM_OPTIONS = [
  "SHOLAT SUBUH (SENDIRI)", "SHOLAT SUBUH (BERJAMA'AH)",
  "SHOLAT DZUHUR (SENDIRI)", "SHOLAT DZUHUR (BERJAMA'AH)",
  "SHOLAT ASHAR (SENDIRI)", "SHOLAT ASHAR (BERJAMA'AH)",
  "SHOLAT MAGHRIB (SENDIRI)", "SHOLAT MAGHRIB (BERJAMA'AH)",
  "SHOLAT ISYA' (SENDIRI)", "SHOLAT ISYA' (BERJAMA'AH)",
  "SHOLAT JUM'AT (SISWA PUTRA)", "SHOLAT SUNNAH", "MENSTRUASI", "NON ISLAM"
];
const sections = [
  { id: 1, title: "Tanggal & Bangun Pagi", icon: "☀️", intro: "Isi tanggal kegiatan dan jam kamu bangun." },
  { id: 2, title: "Ibadah", icon: "🙏", intro: "Isi sesuai agama yang kamu yakini." },
  { id: 3, title: "Berolahraga & Gemar Belajar", icon: "🏃", intro: "Tuliskan kegiatanmu." },
  { id: 4, title: "Makan Sehat Bergizi", icon: "🍎", intro: "Tuliskan makananmu pagi, siang, dan malam." },
  { id: 5, title: "Bermasyarakat", icon: "👥", intro: "Tuliskan kegiatan bermasyarakatmu." },
  { id: 6, title: "Tidur Cepat & Saran", icon: "🌙", intro: "Isi jam tidurmu dan masukan untuk sekolah." }
];
const fields = [
  { id: "tanggal", section: 1, title: "TANGGAL PELAKSANAAN", icon: "📅", type: "date", required: true },
  { id: "bangun_pagi", section: 1, habit: "bangun_pagi", title: "BANGUN PAGI (PUKUL)", icon: "☀️", type: "time", required: true },
  { id: "ibadah_islam", section: 2, habit: "beribadah", title: "2. A IBADAH AGAMA ISLAM", hint: NOTE, icon: "🕌", type: "checkbox", options: ISLAM_OPTIONS, required: true },
  { id: "ibadah_kristen", section: 2, habit: "beribadah", title: "2. B IBADAH AGAMA KRISTEN", hint: NOTE, icon: "⛪", type: "text", required: true },
  { id: "ibadah_katolik", section: 2, habit: "beribadah", title: "2. C IBADAH AGAMA KATHOLIK", hint: NOTE, icon: "✝️", type: "text", required: true },
  { id: "ibadah_hindu", section: 2, habit: "beribadah", title: "2. D IBADAH AGAMA HINDU", hint: NOTE, icon: "🛕", type: "text", required: true },
  { id: "ibadah_budha", section: 2, habit: "beribadah", title: "2. E IBADAH AGAMA BUDHA", hint: NOTE, icon: "☸️", type: "text", required: true },
  { id: "ibadah_konghucu", section: 2, habit: "beribadah", title: "2. F IBADAH AGAMA KONGHUCHU", hint: NOTE, icon: "☯️", type: "text", required: true },
  { id: "berolahraga", section: 3, habit: "berolahraga", title: "3. BEROLAHRAGA", icon: "🏃", type: "text", required: true },
  { id: "gemar_belajar", section: 3, habit: "gemar_belajar", title: "4. GEMAR BELAJAR", icon: "📚", type: "text", required: true },
  { id: "makan_pagi", section: 4, habit: "makan_sehat", title: "5. A. MAKAN SEHAT BERGIZI PAGI", icon: "🍳", type: "text", required: true },
  { id: "makan_siang", section: 4, habit: "makan_sehat", title: "5. B. MAKAN SEHAT BERGIZI SIANG", icon: "🍛", type: "text", required: true },
  { id: "makan_malam", section: 4, habit: "makan_sehat", title: "5. C MAKAN SEHAT BERGIZI MALAM", icon: "🥗", type: "text", required: true },
  { id: "bermasyarakat", section: 5, habit: "bermasyarakat", title: "6. KEGIATAN BERMASYARAKAT", icon: "👥", type: "text", required: true },
  { id: "tidur_cepat", section: 6, habit: "tidur_cepat", title: "7. TIDUR CEPAT (PUKUL)", icon: "🌙", type: "time", required: true },
  { id: "saran", section: 6, title: "Masukan dan Saran", icon: "💬", type: "text", required: false, max: 500 }
];

function cleanAnswers(a) {
  const out = {};
  const limit = new Date(); limit.setDate(limit.getDate() + 1); // toleransi zona waktu
  for (const f of fields) {
    let v = a[f.id];
    const miss = { error: `"${f.title}" belum diisi.` };
    if (f.type === "checkbox") {
      v = Array.isArray(v) ? [...new Set(v.map(String))] : [];
      if (v.some((x) => !f.options.includes(x))) return { error: `Pilihan "${f.title}" tidak valid.` };
      if (f.required && !v.length) return miss;
      out[f.id] = v.join("; ");
      continue;
    }
    v = typeof v === "string" ? v.trim() : "";
    if (!v) { if (f.required) return miss; out[f.id] = ""; continue; }
    if (f.type === "date") {
      const d = new Date(v + "T00:00:00Z");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v) || isNaN(d) || d.toISOString().slice(0, 10) !== v || d > limit || d.getUTCFullYear() < 2020) {
        return { error: "Tanggal pelaksanaan tidak valid." };
      }
      out[f.id] = v;
    } else if (f.type === "time") {
      const m = /^([01]?\d|2[0-3])[.:]([0-5]\d)$/.exec(v);
      if (!m) return { error: `Jam pada "${f.title}" tidak valid.` };
      out[f.id] = `${m[1].padStart(2, "0")}.${m[2]}`;
    } else {
      out[f.id] = v.slice(0, f.max || 300);
    }
  }
  return { clean: out };
}

// Ringkasan rekap per kebiasaan (dihitung dari jawaban tersimpan)
function buildHabitSummary(rows, total) {
  const byResp = {};
  rows.forEach((r) => { (byResp[r.response_id] ||= {})[r.habit_id] = r.answer; });
  const list = Object.values(byResp);
  const real = (v) => !!v && !/^([-–—.\s]*|tidak(\s+ada)?|nihil)$/i.test(String(v).trim());
  const pct = (n, d) => (d ? Math.round((n / d) * 100) : 0);
  const mins = (v, night) => {
    const m = /^(\d{2})\.(\d{2})$/.exec(v || "");
    if (!m) return null;
    let t = Number(m[1]) * 60 + Number(m[2]);
    if (night && Number(m[1]) < 12) t += 1440;
    return t;
  };
  const avgTime = (id, night) => {
    const v = list.map((x) => mins(x[id], night)).filter((x) => x !== null);
    if (!v.length) return null;
    const t = Math.round(v.reduce((a, b) => a + b, 0) / v.length) % 1440;
    return `${String(Math.floor(t / 60)).padStart(2, "0")}.${String(t % 60).padStart(2, "0")}`;
  };
  const doneIbadah = (x) => {
    const islam = (x.ibadah_islam || "").split("; ").filter((o) => o && !["MENSTRUASI", "NON ISLAM"].includes(o));
    return islam.length > 0 || ["ibadah_kristen", "ibadah_katolik", "ibadah_hindu", "ibadah_budha", "ibadah_konghucu"].some((k) => real(x[k]));
  };
  const n = total || list.length;
  const out = {
    bangun_pagi: { kind: "time", value: avgTime("bangun_pagi", false) },
    tidur_cepat: { kind: "time", value: avgTime("tidur_cepat", true) },
    beribadah: { kind: "pct", value: pct(list.filter(doneIbadah).length, n) },
    berolahraga: { kind: "pct", value: pct(list.filter((x) => real(x.berolahraga)).length, n) },
    gemar_belajar: { kind: "pct", value: pct(list.filter((x) => real(x.gemar_belajar)).length, n) },
    bermasyarakat: { kind: "pct", value: pct(list.filter((x) => real(x.bermasyarakat)).length, n) },
    makan_sehat: { kind: "pct", value: pct(list.reduce((a, x) => a + ["makan_pagi", "makan_siang", "makan_malam"].filter((k) => real(x[k])).length, 0), n * 3) }
  };
  return habits.map((h) => ({ id: h.id, title: h.title, icon: h.icon, ...out[h.id] }));
}

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function makeToken() {
  const body = `${ADMIN_USER}:${Date.now()}:${crypto.randomBytes(24).toString("hex")}`;
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(body).digest("hex");
  return Buffer.from(`${body}.${sig}`).toString("base64url");
}
function validToken(token) {
  if (!token) return false;
  try {
    const decoded = Buffer.from(token, "base64url").toString();
    const dot = decoded.lastIndexOf(".");
    if (dot < 1) return false;
    const body = decoded.slice(0, dot);
    const sig = decoded.slice(dot + 1);
    const expected = crypto.createHmac("sha256", SESSION_SECRET).update(body).digest("hex");
    return safeEqual(sig, expected) && body.startsWith(`${ADMIN_USER}:`);
  } catch { return false; }
}
function requireAdmin(req, res, next) {
  if (!validToken(req.headers.authorization?.replace(/^Bearer\s+/i, ""))) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

const MAX_PHOTO = 1.2 * 1024 * 1024; // ~1 MB (klien mengecilkan otomatis)
function parsePhoto(dataUrl) {
  const m = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(String(dataUrl || ""));
  if (!m) return null;
  const buf = Buffer.from(m[2], "base64");
  if (!buf.length || buf.length > MAX_PHOTO) return null;
  const isJpg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const isPng = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
  const isWebp = buf.slice(0, 4).toString() === "RIFF" && buf.slice(8, 12).toString() === "WEBP";
  const ext = isJpg ? "jpg" : isPng ? "png" : isWebp ? "webp" : null;
  return ext ? { buf, ext } : null;
}

app.get("/api/config", (req, res) => res.json({ classes, habits, sections, fields }));

app.post("/api/responses", async (req, res) => {
  try {
    const { name, className, attendance, answers, photo } = req.body || {};
    if (!name || !className || !attendance || !answers || typeof answers !== "object") {
      return res.status(400).json({ error: "Data responden belum lengkap." });
    }
    if (!classes.includes(className)) return res.status(400).json({ error: "Kelas tidak valid." });

    const absent = Number(attendance);
    if (!Number.isInteger(absent) || absent < 1 || absent > 60) {
      return res.status(400).json({ error: "Nomor absen harus berupa angka 1-60." });
    }

    const checked = cleanAnswers(answers);
    if (checked.error) return res.status(400).json({ error: checked.error });
    const clean = checked.clean;
    if (!photo) return res.status(400).json({ error: "Foto dokumentasi wajib diunggah." });

    const responseId = crypto.randomUUID();
    const submittedAt = new Date().toISOString();

    let photoFile = null;
    if (photo) {
      const p = parsePhoto(photo);
      if (!p) return res.status(400).json({ error: "Foto tidak valid (JPG/PNG/WEBP, maksimal 1 MB)." });
      photoFile = `${responseId}.${p.ext}`;
      await fs.promises.writeFile(path.join(UPLOAD_DIR, photoFile), p.buf);
    }

    await run("BEGIN TRANSACTION");
    try {
      await run(
        "INSERT INTO responses(id,name,class_name,attendance,submitted_at,photo) VALUES(?,?,?,?,?,?)",
        [responseId, String(name).trim().slice(0, 100), className, absent, submittedAt, photoFile]
      );
      for (const f of fields) {
        await run(
          "INSERT INTO answers(response_id,habit_id,answer) VALUES(?,?,?)",
          [responseId, f.id, clean[f.id]]
        );
      }
      await run("COMMIT");
    } catch (e) {
      await run("ROLLBACK").catch(() => {});
      if (photoFile) fs.promises.unlink(path.join(UPLOAD_DIR, photoFile)).catch(() => {});
      throw e;
    }

    res.status(201).json({ ok: true, id: responseId });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal menyimpan data." });
  }
});

const attempts = new Map();
app.post("/api/admin/login", (req, res) => {
  const now = Date.now(), rec = attempts.get(req.ip) || { n: 0, t: now };
  if (now - rec.t > 15 * 60 * 1000) { rec.n = 0; rec.t = now; }
  if (rec.n >= 10) return res.status(429).json({ error: "Terlalu banyak percobaan. Coba lagi 15 menit lagi." });
  attempts.set(req.ip, rec);
  const ok = (() => { const { username, password } = req.body || {}; return safeEqual(username, ADMIN_USER) && safeEqual(password, ADMIN_PASSWORD); })();
  if (!ok) rec.n++; else attempts.delete(req.ip);
  if (ok) return res.json({ ok: true, token: makeToken() });
  return res.status(401).json({ error: "Username atau password salah." });
});
app.get("/api/admin/stats", requireAdmin, async (req, res) => {
  try {
    const responses = await all("SELECT * FROM responses ORDER BY submitted_at DESC");
    const answerRows = await all("SELECT response_id, habit_id, answer FROM answers");

    const byClass = Object.fromEntries(classes.map(c => [c, 0]));
    responses.forEach(r => { if (byClass[r.class_name] !== undefined) byClass[r.class_name]++; });
    const habitSummary = buildHabitSummary(answerRows, responses.length);

    res.json({
      total: responses.length,
      lastSubmittedAt: responses[0] ? responses[0].submitted_at : null,
      classesWithResponses: Object.values(byClass).filter(Boolean).length,
      byClass, habitSummary, habits
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal membaca statistik." });
  }
});

app.get("/api/admin/responses", requireAdmin, async (req, res) => {
  try {
    let sql = `SELECT id,name,class_name,attendance,submitted_at,photo FROM responses`;
    const params = [];
    const conditions = [];
    const q = String(req.query.q || "").trim();
    const cls = String(req.query.className || "").trim();

    if (q) {
      conditions.push("(LOWER(name) LIKE LOWER(?) OR LOWER(class_name) LIKE LOWER(?))");
      params.push(`%${q}%`, `%${q}%`);
    }
    if (cls && classes.includes(cls)) {
      conditions.push("class_name = ?");
      params.push(cls);
    }
    if (conditions.length) sql += " WHERE " + conditions.join(" AND ");
    sql += " ORDER BY submitted_at DESC";

    const rows = await all(sql, params);
    for (const r of rows) {
      r.answers = {};
      const a = await all("SELECT habit_id,answer FROM answers WHERE response_id = ?", [r.id]);
      a.forEach(x => { r.answers[x.habit_id] = x.answer; });
      r.className = r.class_name;
      delete r.class_name;
      r.submittedAt = r.submitted_at;
      delete r.submitted_at;
      r.hasPhoto = !!r.photo;
      delete r.photo;
    }
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal membaca data." });
  }
});

app.get("/api/admin/export", requireAdmin, async (req, res) => {
  try {
    const rows = await all("SELECT * FROM responses ORDER BY submitted_at DESC");
    const answers = await all("SELECT response_id,habit_id,answer FROM answers");
    const map = {};
    answers.forEach(a => {
      map[a.response_id] ||= {};
      map[a.response_id][a.habit_id] = a.answer;
    });

    const header = ["Nama","Kelas","No Absen","Waktu Isi",...fields.map(f => f.title),"Foto"];
    const csvRows = rows.map(r => [
      r.name, r.class_name, r.attendance,
      new Date(r.submitted_at).toLocaleString("id-ID"),
      ...fields.map(f => map[r.id]?.[f.id] || ""),
      r.photo ? "Ada" : "Tidak"
    ]);
    const csv = [header, ...csvRows]
      .map(row => row.map(v => `"${String(v).replaceAll('"','""')}"`).join(","))
      .join("\n");

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="7-kaih-data.csv"');
    res.send("\uFEFF" + csv);
  } catch (e) {
    console.error(e);
    res.status(500).send("Gagal membuat CSV.");
  }
});

app.get("/api/admin/photo/:id", requireAdmin, async (req, res) => {
  try {
    if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.status(400).end();
    const row = await get("SELECT photo FROM responses WHERE id = ?", [req.params.id]);
    if (!row || !row.photo || row.photo !== path.basename(row.photo)) return res.status(404).json({ error: "Foto tidak ada." });
    res.setHeader("Cache-Control", "private, max-age=3600");
    res.sendFile(path.join(UPLOAD_DIR, row.photo), (err) => { if (err && !res.headersSent) res.status(404).end(); });
  } catch (e) {
    console.error(e);
    res.status(500).end();
  }
});

app.get("/api/admin/backup", requireAdmin, (req, res) => {
  res.download(DB_FILE, "7-kaih.sqlite");
});

app.use("/api", (req, res) => res.status(404).json({ error: "Endpoint tidak ditemukan." }));
app.use((err, req, res, next) => {
  if (err && err.type === "entity.too.large") return res.status(413).json({ error: "Ukuran data terlalu besar." });
  if (err && err.type === "entity.parse.failed") return res.status(400).json({ error: "Format data salah." });
  console.error(err);
  res.status(500).json({ error: "Terjadi kesalahan server." });
});

ready.then(() => {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`7 KAIH SMPN 27 SEMARANG berjalan di port ${PORT} (database: ${driver})`);
  });
});

// Muat file .env (tanpa dependency tambahan)
try {
  require("fs").readFileSync(require("path").join(__dirname, ".env"), "utf8").split(/\r?\n/).forEach((line) => {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith("#") && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  });
} catch {}

const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const SESSION_SECRET = process.env.SESSION_SECRET || "change-this-secret";

const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "7-kaih.sqlite");

const fs = require("fs");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new sqlite3.Database(DB_FILE);
db.serialize(() => {
  db.run("PRAGMA foreign_keys = ON");
  db.run(`CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY, value TEXT NOT NULL
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS responses (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    class_name TEXT NOT NULL,
    attendance INTEGER NOT NULL,
    submitted_at TEXT NOT NULL
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS answers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    response_id TEXT NOT NULL,
    habit_id TEXT NOT NULL,
    answer TEXT NOT NULL,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    UNIQUE(response_id, habit_id)
  )`);
  db.run("ALTER TABLE responses ADD COLUMN photo TEXT", () => {}); // abaikan error bila kolom sudah ada
  db.run("CREATE INDEX IF NOT EXISTS idx_responses_class ON responses(class_name)");
  db.run("CREATE INDEX IF NOT EXISTS idx_responses_submitted ON responses(submitted_at)");
  db.run("CREATE INDEX IF NOT EXISTS idx_answers_response ON answers(response_id)");
});

app.use(express.json({ limit: "6mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const classes = [];
for (const grade of [7, 8, 9]) {
  for (const letter of "ABCDEFGH") classes.push(`${grade}${letter}`);
}

const habits = [
  { id: "bangun_pagi", title: "Bangun Pagi", icon: "☀️", question: "Seberapa sering kamu bangun pagi sesuai jadwal?" },
  { id: "beribadah", title: "Beribadah", icon: "🙏", question: "Seberapa sering kamu melaksanakan ibadah sesuai agama dan kepercayaanmu?" },
  { id: "berolahraga", title: "Berolahraga", icon: "🏃", question: "Seberapa sering kamu berolahraga atau melakukan aktivitas fisik?" },
  { id: "makan_sehat", title: "Makan Sehat", icon: "🍎", question: "Seberapa sering kamu mengonsumsi makanan sehat dan bergizi?" },
  { id: "gemar_belajar", title: "Gemar Belajar", icon: "📚", question: "Seberapa sering kamu belajar atau membaca untuk menambah pengetahuan?" },
  { id: "bermasyarakat", title: "Bermasyarakat", icon: "👥", question: "Seberapa sering kamu membantu, bekerja sama, dan berinteraksi positif dengan orang lain?" },
  { id: "tidur_cepat", title: "Tidur Cepat", icon: "🌙", question: "Seberapa sering kamu tidur pada waktu yang cukup dan teratur?" }
];

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err); else resolve(this);
    });
  });
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows));
  });
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
  });
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function makeToken() {
  const body = `${ADMIN_USER}:${Date.now()}:${crypto.randomBytes(24).toString("hex")}`;
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(body).digest("hex");
  return Buffer.from(`${body}.${sig}`).toString("base64url");
}
function validToken(token) {
  if (!token) return false;
  try {
    const decoded = Buffer.from(token, "base64url").toString();
    const dot = decoded.lastIndexOf(".");
    if (dot < 1) return false;
    const body = decoded.slice(0, dot);
    const sig = decoded.slice(dot + 1);
    const expected = crypto.createHmac("sha256", SESSION_SECRET).update(body).digest("hex");
    return safeEqual(sig, expected) && body.startsWith(`${ADMIN_USER}:`);
  } catch { return false; }
}
function requireAdmin(req, res, next) {
  if (!validToken(req.headers.authorization?.replace(/^Bearer\s+/i, ""))) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

const MAX_PHOTO = 4 * 1024 * 1024; // 4 MB setelah decode
function parsePhoto(dataUrl) {
  const m = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(String(dataUrl || ""));
  if (!m) return null;
  const buf = Buffer.from(m[2], "base64");
  if (!buf.length || buf.length > MAX_PHOTO) return null;
  const isJpg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const isPng = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
  const isWebp = buf.slice(0, 4).toString() === "RIFF" && buf.slice(8, 12).toString() === "WEBP";
  const ext = isJpg ? "jpg" : isPng ? "png" : isWebp ? "webp" : null;
  return ext ? { buf, ext } : null;
}

app.get("/api/config", (req, res) => res.json({ classes, habits }));

app.post("/api/responses", async (req, res) => {
  try {
    const { name, className, attendance, answers, photo } = req.body || {};
    if (!name || !className || !attendance || !answers || typeof answers !== "object") {
      return res.status(400).json({ error: "Data responden belum lengkap." });
    }
    if (!classes.includes(className)) return res.status(400).json({ error: "Kelas tidak valid." });

    const absent = Number(attendance);
    if (!Number.isInteger(absent) || absent < 1 || absent > 60) {
      return res.status(400).json({ error: "Nomor absen harus berupa angka 1-60." });
    }

    const allowed = ["Selalu", "Sering", "Kadang-kadang", "Jarang", "Tidak Pernah"];
    for (const h of habits) {
      if (!allowed.includes(answers[h.id])) {
        return res.status(400).json({ error: `Jawaban "${h.title}" belum diisi.` });
      }
    }

    const responseId = crypto.randomUUID();
    const submittedAt = new Date().toISOString();

    let photoFile = null;
    if (photo) {
      const p = parsePhoto(photo);
      if (!p) return res.status(400).json({ error: "Foto tidak valid (JPG/PNG/WEBP, maksimal 4 MB)." });
      photoFile = `${responseId}.${p.ext}`;
      await fs.promises.writeFile(path.join(UPLOAD_DIR, photoFile), p.buf);
    }

    await run("BEGIN TRANSACTION");
    try {
      await run(
        "INSERT INTO responses(id,name,class_name,attendance,submitted_at,photo) VALUES(?,?,?,?,?,?)",
        [responseId, String(name).trim().slice(0, 100), className, absent, submittedAt, photoFile]
      );
      for (const h of habits) {
        await run(
          "INSERT INTO answers(response_id,habit_id,answer) VALUES(?,?,?)",
          [responseId, h.id, answers[h.id]]
        );
      }
      await run("COMMIT");
    } catch (e) {
      await run("ROLLBACK").catch(() => {});
      if (photoFile) fs.promises.unlink(path.join(UPLOAD_DIR, photoFile)).catch(() => {});
      throw e;
    }

    res.status(201).json({ ok: true, id: responseId });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal menyimpan data." });
  }
});

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  if (safeEqual(username, ADMIN_USER) && safeEqual(password, ADMIN_PASSWORD)) {
    return res.json({ ok: true, token: makeToken() });
  }
  res.status(401).json({ error: "Username atau password salah." });
});

app.get("/api/admin/stats", requireAdmin, async (req, res) => {
  try {
    const responses = await all("SELECT * FROM responses ORDER BY submitted_at DESC");
    const answerRows = await all("SELECT habit_id, answer, COUNT(*) AS total FROM answers GROUP BY habit_id, answer");

    const byClass = Object.fromEntries(classes.map(c => [c, 0]));
    responses.forEach(r => { if (byClass[r.class_name] !== undefined) byClass[r.class_name]++; });

    const answerStats = {};
    for (const h of habits) {
      answerStats[h.id] = Object.fromEntries(["Selalu","Sering","Kadang-kadang","Jarang","Tidak Pernah"].map(v => [v, 0]));
    }
    answerRows.forEach(r => {
      if (answerStats[r.habit_id] && answerStats[r.habit_id][r.answer] !== undefined) {
        answerStats[r.habit_id][r.answer] = r.total;
      }
    });

    res.json({
      total: responses.length,
      lastSubmittedAt: responses[0] ? responses[0].submitted_at : null,
      classesWithResponses: Object.values(byClass).filter(Boolean).length,
      byClass, answerStats, habits
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal membaca statistik." });
  }
});

app.get("/api/admin/responses", requireAdmin, async (req, res) => {
  try {
    let sql = `SELECT id,name,class_name,attendance,submitted_at,photo FROM responses`;
    const params = [];
    const conditions = [];
    const q = String(req.query.q || "").trim();
    const cls = String(req.query.className || "").trim();

    if (q) {
      conditions.push("(LOWER(name) LIKE LOWER(?) OR LOWER(class_name) LIKE LOWER(?))");
      params.push(`%${q}%`, `%${q}%`);
    }
    if (cls && classes.includes(cls)) {
      conditions.push("class_name = ?");
      params.push(cls);
    }
    if (conditions.length) sql += " WHERE " + conditions.join(" AND ");
    sql += " ORDER BY submitted_at DESC";

    const rows = await all(sql, params);
    for (const r of rows) {
      r.answers = {};
      const a = await all("SELECT habit_id,answer FROM answers WHERE response_id = ?", [r.id]);
      a.forEach(x => { r.answers[x.habit_id] = x.answer; });
      r.className = r.class_name;
      delete r.class_name;
      r.submittedAt = r.submitted_at;
      delete r.submitted_at;
      r.hasPhoto = !!r.photo;
      delete r.photo;
    }
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Gagal membaca data." });
  }
});

app.get("/api/admin/export", requireAdmin, async (req, res) => {
  try {
    const rows = await all("SELECT * FROM responses ORDER BY submitted_at DESC");
    const answers = await all("SELECT response_id,habit_id,answer FROM answers");
    const map = {};
    answers.forEach(a => {
      map[a.response_id] ||= {};
      map[a.response_id][a.habit_id] = a.answer;
    });

    const header = ["Nama","Kelas","No Absen","Waktu",...habits.map(h => h.title)];
    const csvRows = rows.map(r => [
      r.name, r.class_name, r.attendance,
      new Date(r.submitted_at).toLocaleString("id-ID"),
      ...habits.map(h => map[r.id]?.[h.id] || "")
    ]);
    const csv = [header, ...csvRows]
      .map(row => row.map(v => `"${String(v).replaceAll('"','""')}"`).join(","))
      .join("\n");

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="7-kaih-data.csv"');
    res.send("\uFEFF" + csv);
  } catch (e) {
    console.error(e);
    res.status(500).send("Gagal membuat CSV.");
  }
});

app.get("/api/admin/photo/:id", requireAdmin, async (req, res) => {
  try {
    if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.status(400).end();
    const row = await get("SELECT photo FROM responses WHERE id = ?", [req.params.id]);
    if (!row || !row.photo || row.photo !== path.basename(row.photo)) return res.status(404).json({ error: "Foto tidak ada." });
    res.setHeader("Cache-Control", "private, max-age=3600");
    res.sendFile(path.join(UPLOAD_DIR, row.photo), (err) => { if (err && !res.headersSent) res.status(404).end(); });
  } catch (e) {
    console.error(e);
    res.status(500).end();
  }
});

app.get("/api/admin/backup", requireAdmin, (req, res) => {
  res.download(DB_FILE, "7-kaih.sqlite");
});

app.listen(PORT, () => {
  console.log(`7 KAIH SMPN 27 SEMARANG berjalan di http://localhost:${PORT}`);
});

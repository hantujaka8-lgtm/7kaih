/* 7 KAIH — kuesioner satu pertanyaan per layar */
(function () {
  "use strict";
  var K = window.KAIH, $ = function (s) { return document.querySelector(s); };
  var OPTS = [
    ["Selalu", "Selalu (setiap hari)"],
    ["Sering", "Sering (4–5 kali seminggu)"],
    ["Kadang-kadang", "Kadang-kadang (2–3 kali seminggu)"],
    ["Jarang", "Jarang (1 kali seminggu)"],
    ["Tidak Pernah", "Tidak Pernah"]
  ];
  var cfg = null, idx = 0, answers = {}, sending = false;

  function setStep(n) {
    document.querySelectorAll(".step").forEach(function (el) {
      var s = Number(el.dataset.s);
      el.classList.toggle("active", s === n);
      el.classList.toggle("done", s < n);
      if (s < n) el.querySelector("i").textContent = "✓";
    });
    $("#stepFill").style.width = ((n - 1) / 2) * 100 + "%";
  }

  function show(id) {
    ["identity", "questions", "done"].forEach(function (x) { $("#" + x).classList.toggle("hidden", x !== id); });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function progress() {
    var done = Object.keys(answers).length, pct = Math.round(done / cfg.habits.length * 100);
    $("#progressFill").style.width = pct + "%";
    $("#qPct").textContent = pct + "%";
  }

  function render(dir) {
    var h = cfg.habits[idx], last = idx === cfg.habits.length - 1;
    var card = $("#qCard");
    card.innerHTML =
      '<div class="q-title"><div class="q-ico">' + K.esc(h.icon) + "</div><div><h3>" + (idx + 1) + ". " + K.esc(h.title) +
      "</h3><p>" + K.esc(h.question) + '</p></div></div><div class="options">' +
      OPTS.map(function (o, i) {
        return '<label class="option" style="--i:' + i + '"><input type="radio" name="opt" value="' + o[0] + '"' +
          (answers[h.id] === o[0] ? " checked" : "") + "><span>" + o[1] + "</span></label>";
      }).join("") + "</div>";
    card.classList.remove("swap"); void card.offsetWidth;
    card.dataset.dir = dir || 1; card.classList.add("swap");
    $("#qCount").textContent = "Pertanyaan " + (idx + 1) + " dari " + cfg.habits.length;
    $("#back").disabled = false;
    var next = $("#next");
    next.disabled = !answers[h.id];
    next.textContent = last ? "Kirim Jawaban ✓" : "Selanjutnya →";
    progress();
  }

  function flash(el) {
    el.classList.add("err");
    setTimeout(function () { el.classList.remove("err"); }, 600);
  }

  function start() {
    var n = $("#name"), c = $("#className"), a = $("#attendance");
    var bad = false;
    if (!n.value.trim()) { flash(n); bad = true; }
    if (!c.value) { flash(c); bad = true; }
    var num = Number(a.value);
    if (!a.value || !Number.isInteger(num) || num < 1 || num > 60) { flash(a); bad = true; }
    if (bad) return K.toast("Lengkapi nama, kelas, dan nomor absen (1–60).", "error");
    if (!cfg) return K.toast("Data belum termuat, coba muat ulang halaman.", "error");
    idx = 0; setStep(2); show("questions"); render(1);
  }

  function submit() {
    if (sending) return;
    sending = true;
    var btn = $("#next");
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Mengirim...';
    fetch("/api/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: $("#name").value.trim(),
        className: $("#className").value,
        attendance: $("#attendance").value,
        answers: answers
      })
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) { return { ok: r.ok, d: d }; });
    }).then(function (res) {
      if (!res.ok) throw new Error(res.d.error || "Gagal menyimpan.");
      setStep(3); show("done"); K.confetti($("#done"), 40);
      document.querySelectorAll(".step")[2].querySelector("i").textContent = "✓";
    }).catch(function (e) {
      K.toast(e.message || "Gagal terhubung ke server.", "error");
      btn.disabled = false; btn.textContent = "Kirim Jawaban ✓";
    }).then(function () { sending = false; });
  }

  $("#start").addEventListener("click", start);
  $("#attendance").addEventListener("keydown", function (e) { if (e.key === "Enter") start(); });

  $("#qCard").addEventListener("change", function (e) {
    if (e.target.name !== "opt") return;
    answers[cfg.habits[idx].id] = e.target.value;
    $("#next").disabled = false;
    progress();
  });

  $("#next").addEventListener("click", function () {
    if (!answers[cfg.habits[idx].id]) return;
    if (idx < cfg.habits.length - 1) { idx++; render(1); } else submit();
  });

  $("#back").addEventListener("click", function () {
    if (idx > 0) { idx--; render(-1); } else { setStep(1); show("identity"); }
  });

  fetch("/api/config").then(function (r) { return r.json(); }).then(function (c) {
    cfg = c;
    var s = $("#className");
    c.classes.forEach(function (x) { var o = document.createElement("option"); o.value = x; o.textContent = x; s.appendChild(o); });
  }).catch(function () { K.toast("Gagal memuat data dari server.", "error"); });
})();

/* 7 KAIH — panel admin */
(function () {
  "use strict";
  var K = window.KAIH, $ = function (s) { return document.querySelector(s); };
  var token = null, config = null, rows = [], page = 1, PER = 10, timer = null;
  try { token = localStorage.getItem("kaih_token"); } catch (e) {}
  var TITLES = {
    dashboard: ["Dashboard Admin", "Selamat datang di panel admin 7 KAIH SMPN 27 SEMARANG"],
    responses: ["Data Responden", "Seluruh jawaban siswa yang sudah masuk"],
    summary: ["Rekap Hasil Kuesioner", "Data diambil dari seluruh responden 7 KAIH"],
    settings: ["Pengaturan", "Informasi sistem"]
  };
  var SCORE = { "Selalu": 5, "Sering": 4, "Kadang-kadang": 3, "Jarang": 2, "Tidak Pernah": 1 };
  var COLORS = ["#2563eb", "#22a55b", "#f59e0b", "#8b5cf6", "#ef4444", "#06b6d4", "#14b8a6"];

  function api(url, opt) {
    opt = opt || {};
    opt.headers = Object.assign({}, opt.headers, { Authorization: "Bearer " + token });
    return fetch(url, opt).then(function (r) {
      if (r.status === 401) { logout(); throw new Error("Sesi berakhir, silakan login lagi."); }
      return r;
    });
  }
  function logout() {
    try { localStorage.removeItem("kaih_token"); } catch (e) {}
    location.reload();
  }
  function fmt(d) { return d ? new Date(d).toLocaleString("id-ID", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "-"; }

  function statCard(i, ico, tint, val, label, sub) {
    return '<div class="stat" style="--i:' + i + ';--tint:' + tint + '"><div class="ico">' + ico + '</div><div><span>' + label +
      "</span><b>" + val + "</b><small>" + sub + "</small></div></div>";
  }

  function chart(chartEl, labelsEl, items) {
    var max = Math.max.apply(null, items.map(function (x) { return x.v; }).concat([1]));
    chartEl.innerHTML = items.map(function (x, i) {
      return '<div class="bar" title="' + K.esc(x.l) + ": " + x.v + x.suffix + '"><b>' + x.v + x.suffix + '</b><i style="--h:' + Math.round(x.v / max * 100) +
        "%;--c:" + x.c + ";--i:" + i + '"></i></div>';
    }).join("");
    labelsEl.innerHTML = items.map(function (x) { return "<span>" + K.esc(x.l) + "</span>"; }).join("");
  }

  function loadStats() {
    return api("/api/admin/stats").then(function (r) { return r.json(); }).then(function (s) {
      var total = s.total, nClass = Object.keys(s.byClass).length;
      $("#stats").innerHTML =
        statCard(0, "🧑‍🎓", "#e3efff", '<em style="font-style:normal" data-n="' + total + '">0</em>', "Total Responden", "Siswa") +
        statCard(1, "🏫", "#d8f6e4", '<em style="font-style:normal" data-n="' + s.classesWithResponses + '">0</em>', "Kelas Terisi", "dari " + nClass + " kelas") +
        statCard(2, "📝", "#e5e0ff", '<em style="font-style:normal" data-n="' + s.habits.length + '">0</em>', "Kuesioner Aktif", "Kebiasaan") +
        statCard(3, "🕒", "#ffe9cf", '<span style="font-size:14px;color:inherit">' + fmt(s.lastSubmittedAt) + "</span>", "Terakhir Update", "");
      $("#stats").querySelectorAll("[data-n]").forEach(function (e) { K.countUp(e, e.dataset.n, 900); });

      chart($("#classChart"), $("#classLabels"), Object.keys(s.byClass).map(function (c, i) {
        return { l: c, v: s.byClass[c], suffix: "", c: COLORS[i % COLORS.length] };
      }));
      renderSummary(s);
    });
  }

  function renderSummary(s) {
    var stats = s.habits.map(function (h, i) {
      var a = s.answerStats[h.id], t = 0, sc = 0;
      Object.keys(a).forEach(function (k) { t += a[k]; sc += a[k] * SCORE[k]; });
      var good = a["Selalu"] + a["Sering"];
      var top = Object.keys(a).sort(function (x, y) { return a[y] - a[x]; })[0];
      return { h: h, t: t, avg: t ? sc / t : 0, pct: t ? Math.round(good / t * 100) : 0, good: good, top: top, c: COLORS[i % COLORS.length] };
    });
    var all = stats.reduce(function (n, x) { return n + x.t; }, 0);
    var avg = all ? stats.reduce(function (n, x) { return n + x.avg * x.t; }, 0) / all : 0;
    var pct = all ? Math.round(stats.reduce(function (n, x) { return n + x.good; }, 0) / all * 100) : 0;
    $("#summaryTop").innerHTML =
      statCard(0, "⭐", "#e3efff", avg.toFixed(1) + " / 5", "Rata-rata Skor", "") +
      statCard(1, "🧑‍🎓", "#d8f6e4", s.total, "Peserta", "siswa") +
      statCard(2, "✅", "#e5f8ec", pct + "%", "Persentase Penerapan", "Selalu + Sering");
    chart($("#habitChart"), $("#habitLabels"), stats.map(function (x) { return { l: x.h.title, v: x.pct, suffix: "%", c: x.c }; }));
    $("#summaryCards").innerHTML = stats.map(function (x, i) {
      return '<article class="summary" style="--i:' + i + '"><div>' + K.esc(x.h.icon) + "</div><h3>" + K.esc(x.h.title) + "</h3><p>" +
        (x.t ? x.pct + "% Selalu/Sering · terbanyak <b>" + K.esc(x.top) + "</b>" : "Belum ada data") + "</p></article>";
    }).join("");
    if (!all) { $("#conclusion").innerHTML = "🏆 <div><b>Kesimpulan</b><br>Belum ada responden. Kesimpulan muncul setelah siswa mengisi kuesioner.</div>"; return; }
    var sorted = stats.slice().sort(function (a, b) { return b.pct - a.pct; });
    $("#conclusion").innerHTML = "🏆 <div><b>Kesimpulan</b><br>Secara umum, siswa sudah menerapkan 7 kebiasaan dengan skor rata-rata " + avg.toFixed(1) +
      " dari 5. Kebiasaan tertinggi adalah <b>" + K.esc(sorted[0].h.title) + "</b> (" + sorted[0].pct + "%), sedangkan yang perlu ditingkatkan adalah <b>" +
      K.esc(sorted[sorted.length - 1].h.title) + "</b> (" + sorted[sorted.length - 1].pct + "%).</div>";
  }

  function loadRows() {
    var q = $("#search").value.trim(), cl = $("#filterClass").value;
    return api("/api/admin/responses?" + new URLSearchParams({ q: q, className: cl })).then(function (r) { return r.json(); }).then(function (d) {
      rows = Array.isArray(d) ? d : []; page = 1; drawRows();
    });
  }

  function drawRows() {
    var pages = Math.max(1, Math.ceil(rows.length / PER));
    page = Math.min(page, pages);
    var start = (page - 1) * PER;
    $("#rows").innerHTML = rows.slice(start, start + PER).map(function (r, i) {
      return '<tr style="--i:' + i + '"><td>' + (start + i + 1) + "</td><td><b>" + K.esc(r.name) + "</b></td><td>" + K.esc(r.className) + "</td><td>" +
        r.attendance + "</td><td>" + fmt(r.submittedAt) + '</td><td><button class="text-btn" data-i="' + (start + i) + '" type="button">Lihat</button></td></tr>';
    }).join("") || '<tr><td colspan="6" class="muted">Belum ada data.</td></tr>';
    var b = '<button data-p="' + (page - 1) + '"' + (page <= 1 ? " disabled" : "") + ">‹</button>";
    for (var p = 1; p <= pages; p++) {
      if (p === 1 || p === pages || Math.abs(p - page) <= 1) b += '<button data-p="' + p + '"' + (p === page ? ' class="on"' : "") + ">" + p + "</button>";
      else if (Math.abs(p - page) === 2) b += "<button disabled>…</button>";
    }
    b += '<button data-p="' + (page + 1) + '"' + (page >= pages ? " disabled" : "") + ">›</button>";
    $("#pager").innerHTML = pages > 1 ? b : "";
  }

  function openDetail(r) {
    $("#modalBody").innerHTML =
      '<div class="info-grid"><div><span>Nama</span><b>' + K.esc(r.name) + "</b></div><div><span>Nomor Absen</span><b>" + r.attendance +
      "</b></div><div><span>Kelas</span><b>" + K.esc(r.className) + "</b></div><div><span>Waktu Isi</span><b>" + fmt(r.submittedAt) + '</b></div></div><div class="ans-grid">' +
      config.habits.map(function (h) {
        return '<div class="ans"><em>' + K.esc(h.icon) + "</em><div><b>" + K.esc(h.title) + "</b><small>" + K.esc(r.answers[h.id] || "-") + "</small></div></div>";
      }).join("") + "</div>";
    $("#modal").classList.remove("hidden");
  }
  function closeDetail() { $("#modal").classList.add("hidden"); }

  function download(url, name) {
    api(url).then(function (r) { if (!r.ok) throw new Error("Gagal mengunduh."); return r.blob(); }).then(function (b) {
      var a = document.createElement("a");
      a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    }).catch(function (e) { K.toast(e.message, "error"); });
  }

  function openPage(p) {
    document.querySelectorAll(".page").forEach(function (x) { x.classList.add("hidden"); });
    $("#" + p).classList.remove("hidden");
    document.querySelectorAll(".side[data-page]").forEach(function (x) { x.classList.toggle("active", x.dataset.page === p); });
    $("#pageTitle").textContent = TITLES[p][0]; $("#pageSub").textContent = TITLES[p][1];
    if (p === "dashboard" || p === "summary") loadStats().catch(function (e) { K.toast(e.message, "error"); });
    if (p === "responses") loadRows().catch(function (e) { K.toast(e.message, "error"); });
  }

  function boot() {
    if (!token) return;
    fetch("/api/config").then(function (r) { return r.json(); }).then(function (c) {
      config = c;
      c.classes.forEach(function (x) { var o = document.createElement("option"); o.value = x; o.textContent = x; $("#filterClass").appendChild(o); });
      return api("/api/admin/stats");
    }).then(function (r) {
      if (!r.ok) throw new Error("x");
      $("#login").classList.add("hidden"); $("#app").classList.remove("hidden");
      return loadStats();
    }).catch(function () { /* token tidak valid: tetap di halaman login */ });
  }

  $("#loginBtn").addEventListener("click", function () {
    var btn = $("#loginBtn");
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Masuk...';
    fetch("/api/admin/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: $("#user").value, password: $("#pass").value })
    }).then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); }).then(function (res) {
      if (!res.ok) throw new Error(res.d.error || "Login gagal.");
      token = res.d.token;
      try { localStorage.setItem("kaih_token", token); } catch (e) {}
      K.toast("Login berhasil. Selamat datang!", "ok");
      boot();
    }).catch(function (e) { K.toast(e.message || "Gagal terhubung ke server.", "error"); })
      .then(function () { btn.disabled = false; btn.textContent = "Login →"; });
  });
  $("#pass").addEventListener("keydown", function (e) { if (e.key === "Enter") $("#loginBtn").click(); });
  $("#user").addEventListener("keydown", function (e) { if (e.key === "Enter") $("#pass").focus(); });
  $("#logout").addEventListener("click", logout);
  document.querySelectorAll(".side[data-page]").forEach(function (b) { b.addEventListener("click", function () { openPage(b.dataset.page); }); });
  $("#search").addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(function () { loadRows().catch(function () {}); }, 250); });
  $("#filterClass").addEventListener("change", function () { loadRows().catch(function () {}); });
  $("#export").addEventListener("click", function () { download("/api/admin/export", "7-kaih-data.csv"); });
  $("#backup").addEventListener("click", function () { download("/api/admin/backup", "7-kaih.sqlite"); });
  $("#rows").addEventListener("click", function (e) { var b = e.target.closest("[data-i]"); if (b) openDetail(rows[Number(b.dataset.i)]); });
  $("#pager").addEventListener("click", function (e) { var b = e.target.closest("[data-p]"); if (b && !b.disabled) { page = Number(b.dataset.p); drawRows(); } });
  $("#closeModal").addEventListener("click", closeDetail);
  $("#modal").addEventListener("click", function (e) { if (e.target.id === "modal") closeDetail(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeDetail(); });
  boot();
})();
